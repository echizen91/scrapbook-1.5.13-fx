
if ("Cc" in window == false) {
	window.Cc = Components.classes;
	window.Ci = Components.interfaces;
}

Components.utils.import("resource://scrapbook-modules/utils.jsm");
Components.utils.import("resource://scrapbook-modules/data.jsm");


